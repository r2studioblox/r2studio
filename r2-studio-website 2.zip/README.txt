r2 studio — website

Isi folder:
  index.html          halaman utama
  style.css           tampilan
  script.js           isi dan pengaturan (cari bagian CONFIG di paling atas)
  assets/images       semua foto
  assets/favicon.png  ikon tab browser

Cara upload ke Netlify:
  1. Buka app.netlify.com/drop
  2. Seret file ZIP ini (atau folder hasil ekstraknya) ke halaman itu
  3. Tunggu selesai, lalu salin link publiknya

Cara edit setelah online:
  - Ubah teks, link Discord, status buka/tutup, atau daftar foto di script.js (bagian CONFIG)
  - Foto baru: taruh di assets/images, lalu daftarkan di CONFIG
  - Upload ulang ke Netlify untuk memperbarui
